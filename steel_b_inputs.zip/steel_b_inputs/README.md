# 炼钢 B 题排程输入包

将 `steel_inputs` 文件夹复制到队伍的 `main.py` 同级目录。现成输入在 `steel_inputs/data/inputs.json`，Python 3.10 及以上可直接读取。

```python
from steel_inputs import load_inputs

data = load_inputs()
jobs = data.jobs_for_cast("CC3", "6C0776")
for job in jobs:
    process_seconds = [stage.planned_seconds for stage in job.stages]
    transport_seconds = [data.transport_seconds(edge) for edge in job.transport_edges]
    print(job.heat_id, job.cast_start, process_seconds, transport_seconds)
```

示例连连浇号仅用于演示接入。可以用 `data.jobs` 读取全部计划，或用 `data.jobs_between(start, end)` 按计划开浇时间选算例。时间为原表的本地时间，区间左端包含、右端不包含。排程程序还需处理时间窗口开始前已在厂内的钢包和设备占用。

## 数据内容

| 字段 | 含义与使用方式 |
|---|---|
| `jobs` | 1,266 个有正式熔炼号的计划炉次。每炉保留制造命令号、计划设备、精炼顺序、浇次标识、计划起止时间、原表行号和异常标记。 |
| `jobs[i].stages` | 工序按 `BOF` 转炉、路线指定的 `LF` 和/或 `RH`、`CC` 连铸排列。精炼设备为候选名单，设备指派由排程模型处理。 |
| `transport` | 六类重包从起吊到到位的耗时汇总，单位为分钟。`transport_seconds()` 默认取汇总表中位数并换算成整数秒。该方法也接受 `p10`、`p90`。 |
| `transport_samples` | 2,867 条可回查的实际吊运时间，可按 `route` 抽样。每条记录保留整理表行号和原主表行号。 |
| `process_stats` | 34 条工序与其他间隔统计。按照 `kind` 区分加工时段和观察到的总间隔。零样本的耗时留空。 |
| `weight_stats` | 重包毛重、空包重量和钢水净重的统计，单位为吨。用行车吨位核对任务时应采用重包毛重。 |
| `history` | 1,350 条带熔炼号的实际工序记录。同一熔炼号可以对应多条记录，`history_for()` 返回全部候选。 |
| `rejected_plan_rows`、`rejected_history_rows` | 55 条计划占位记录及 5 条缺熔炼号的历史记录，保留来源行号。 |
| `resources`、`transport_rules`、`waiting_rules` | 设备清单、运输关系、等待定义及数据边界。另保留全部已使用输入文件的 SHA-256。 |

## 接入时需要核对的地方

- 路线以计划的 `L0/R0/L0R0/R0L0` 字段为准，精炼时间列按设备类型读取。额外填入但不属于该炉路线的时段会标记为 `unused_plan_slot`。
- 计划连铸机字母按 A、B、C 映射为 1、2、3 号。与实际连铸记录对照后，1,084 炉的观测与计划一致，21 炉有差异或多条对应，161 炉未匹配到观测。实际记录不覆盖计划。
- 转炉到 LF、LF 到连铸两类，汇总样本数分别是 769、819，当前明细分别是 766、816。两种计数各自保留，第一问可取汇总中位数，第二问使用实际可读明细。
- 计划时段给出参考工期和计划时点。哪些时间固定、哪些可调整由模型设置。计划时间重叠、历史逆序和重复记录会保留标记。历史总间隔可能包含设备动作与等待，分段计时前需对齐事件边界。
- 行车轨道坐标、空车转场时间、跨区交接参数和缺失的空包回程时长需要补充。未核实的参数保留空值，排程程序应显式设置假设或报告缺项。

## 运行示例和测试

```text
python main.py
python -m unittest discover -s tests -v
```

用新版原始表重新生成输入时，先安装 Excel 读取依赖，再指定原表目录、两份整理表和输出文件。建议先输出到新位置，确认数据版本后再替换主程序输入。

```text
python -m pip install openpyxl xlrd
python -m steel_inputs.import_workbooks --raw-dir "附数据文件目录" --parameters "炼钢生产线参数与数据核查.xlsx" --relations "钢包运输与等待关系.xlsx" --output "inputs_new.json"
```

如果需要安装到其他 Python 项目，可在此目录运行 `python -m pip install .`。随包输入可以通过 `load_inputs()` 读取，也可以用 `load_inputs("inputs_new.json")` 加载更新后的数据。
